//kriterler 1-5 arası oylanir. yorum yazilabilir.submit edildikten sonra yarisma sayfasina donulur
import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { io } from 'socket.io-client';
import { UserContext } from '../UserContext';
import './styles.css';

const socket = io('http://localhost:5000');

function VotePage() {
    const { competitionId, projectId } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const { user } = useContext(UserContext);
    const [competition, setCompetition] = useState(null);
    const [votes, setVotes] = useState({});
    const [isJury, setIsJury] = useState(false);
    const [comment, setComment] = useState('');

    useEffect(() => {
        if (!user.name || !user.role) {
            navigate('/');
            return;
        }

        socket.emit('requestCompetitionData', { competitionId });

        socket.on('competitionData', (data) => {
            setCompetition(data);
            setIsJury(location.state?.juryMembers.includes(user.name));

            const initialVotes = {};
            data.criteria.forEach((criterion) => {
                initialVotes[criterion] = 3; // Default value
            });
            setVotes(initialVotes);
        });

        return () => {
            socket.off('competitionData');
        };
    }, [competitionId, user, navigate, location.state]);

    const handleVoteChange = (criterion, score) => {
        setVotes((prevVotes) => ({
            ...prevVotes,
            [criterion]: score,
        }));
    };

    const submitVotes = () => {
        const totalScore = Object.values(votes).reduce((sum, score) => sum + score, 0);
        const averageScore = totalScore / Object.keys(votes).length;
        const finalScore = isJury ? averageScore * 2 : averageScore;

        socket.emit('submitVotes', {
            competitionId,
            projectId,
            finalScore,
            userName: user.name,
            comment: comment.trim(),
        });

        navigate(`/competition/${competitionId}`);
    };

    if (!competition) {
        return <div>Yükleniyor...</div>;
    }

    const project = competition.projects.find((p) => p.id === projectId);
    if (!project) {
        return <div>Proje bulunamadı.</div>;
    }


        return (
            <div className="container">
                <h2>{project.name} için Oy Verin</h2>
                {isJury && <p className="jury-info">Jüri üyesi olarak atandınız. Oylarınız iki katı değerindedir.</p>}
                <div className="likert-container">
                    {competition.criteria.map((criterion, index) => (
                        <div key={index} className="likert-item" style={{ marginBottom: '15px' }}>
                            <label>{criterion}: </label>
                            <div className="likert-buttons">
                                {[1, 2, 3, 4, 5].map((score) => (
                                    <button
                                        key={score}
                                        onClick={() => handleVoteChange(criterion, score)}
                                        className={votes[criterion] === score ? 'selected' : ''}>
                                        {score}
                                    </button>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
                <div style={{ marginTop: '15px' }}>
                    <label>Yorum Bırakın:</label>
                    <textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Yorumunuzu buraya yazın..."
                    />
                </div>
                <button onClick={submitVotes} style={{ width: '100%', marginTop: '20px' }}>
                    Oyları Gönder
                </button>
            </div>
        );
}

export default VotePage;
