// yarisma sayfasi. projeler ve katilimcilar goruntulenir
import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import { UserContext } from '../UserContext';
import './styles.css';

const socket = io('http://localhost:5000');

function CompetitionPage() {
    const { competitionId } = useParams();
    const navigate = useNavigate();
    const { user } = useContext(UserContext);

    const [competition, setCompetition] = useState(null);
    const [juryMembers, setJuryMembers] = useState([]);
    const [votingStarted, setVotingStarted] = useState(false);
    const [votingFinished, setVotingFinished] = useState(false);
    const [resultsVisible, setResultsVisible] = useState(false);

    useEffect(() => {
        if (!user.name || !user.role) {
            navigate('/');
            return;
        }

        socket.emit('joinCompetition', { competitionId, name: user.name });

        socket.on('competitionData', (data) => {
            const uniqueUsers = Array.from(new Set(data.connectedUsers.map(u => u.name)))
                .map(name => data.connectedUsers.find(u => u.name === name));

            setCompetition({
                ...data,
                connectedUsers: uniqueUsers,
            });
            setJuryMembers(data.juryMembers || []);
            setVotingStarted(data.votingStarted || false);
            setVotingFinished(data.votingFinished || false);
            setResultsVisible(data.resultsVisible || false);
        });

        return () => {
            socket.off('competitionData');
        };
    }, [competitionId, user, navigate]);

    // jury ataması
    const toggleJuryMember = (userName) => {
        const updatedJury = juryMembers.includes(userName)
            ? juryMembers.filter((jury) => jury !== userName)
            : [...juryMembers, userName];

        setJuryMembers(updatedJury);
        socket.emit('updateJuryMembers', { competitionId, juryMembers: updatedJury });
    };

    const startVoting = () => {
        setVotingStarted(true);
        socket.emit('startVoting', { competitionId });
    };

    const finishVoting = () => {
        setVotingStarted(false);
        setVotingFinished(true);
        socket.emit('finishVoting', { competitionId });
    };

    const handleVote = (projectId) => {
        navigate(`/competition/${competitionId}/vote/${projectId}`, { state: { juryMembers } });
    };

    const handleShowResults = () => {
        socket.emit('showResults', { competitionId });
        setResultsVisible(true);
    };

    const returnToLobby = () => {
        navigate('/lobby');
    };

    if (!competition) {
        return <div>Yükleniyor...</div>;
    }

    const sortedProjects = resultsVisible
        ? [...competition.projects].sort((a, b) => b.averageScore - a.averageScore)
        : competition.projects;

        return (
            <div className="container">
                <h1>{competition.name}</h1>
                <h3>Tarih: {competition.date || 'Tarih belirtilmedi'}</h3>
                <h3>Projeler</h3>
                <div className="card-container">
                    {sortedProjects.map((project, index) => (
                        <div key={project.id} className={`card ${index === 0 && resultsVisible ? 'highlight' : ''}`}>
                            <div className="card-content">
                                <h4>{project.name}</h4>
                                <p>{project.description}</p>
                                {resultsVisible && (
                                    <>
                                        <p>Ortalama Puan: {project.averageScore.toFixed(2)}</p>
                                        {(user.role === 'admin' || user.role === 'member') && (
                                            <ul style={{ marginTop: '10px' }}>
                                                {project.comments.map((comment, index) => (
                                                    <li key={index}>
                                                        <strong>{comment.userName}:</strong> {comment.comment}
                                                    </li>
                                                ))}
                                            </ul>
                                        )}
                                    </>
                                )}
                            </div>
                            <div className="card-actions" style={{ marginTop: '15px' }}>
                                <button
                                    onClick={() => handleVote(project.id)}
                                    disabled={!votingStarted || project.votes[user.name]}>
                                    {project.votes[user.name] ? 'Oy Kullanıldı' : 'Oy Ver'}
                                </button>
                                {project.votes[user.name] && <p style={{ marginTop: '10px' }}>Bu projeye zaten oy verdiniz.</p>}
                            </div>
                        </div>
                    ))}
                </div>
                <h3>Bağlı Kullanıcılar</h3>
                <div className="card-container">
                    {competition.connectedUsers.map((connectedUser, index) => (
                        <div key={index} className="card">
                            <div className="card-content">
                                <p>
                                    {connectedUser.name} {juryMembers.includes(connectedUser.name) && <span>(jüri)</span>}
                                </p>
                            </div>
                            {(user.role === 'admin' || user.role === 'member') && connectedUser.name !== user.name && (
                                <div className="card-actions">
                                    <button onClick={() => toggleJuryMember(connectedUser.name)}>
                                        {juryMembers.includes(connectedUser.name)
                                            ? 'Jüriden Çıkar'
                                            : 'Jüriye Ekle'}
                                    </button>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
                {(user.role === 'admin' || user.role === 'member') && (
                    <div style={{ marginTop: '20px' }}>
                        <button onClick={startVoting} disabled={votingStarted || votingFinished}>
                            Oylamayı Başlat
                        </button>
                        <button onClick={finishVoting} disabled={!votingStarted} style={{ marginLeft: '10px' }}>
                            Oylamayı Bitir
                        </button>
                        {!resultsVisible && votingFinished && (
                            <button onClick={handleShowResults} style={{ marginLeft: '10px' }}>
                                Sonuçları Gör
                            </button>
                        )}
                    </div>
                )}
                {resultsVisible && (
                    <div style={{ marginTop: '20px' }}>
                        <button onClick={returnToLobby}>Lobiye Dön</button>
                    </div>
                )}
            </div>
        );
}

export default CompetitionPage;
