// yarismayla ilgili bilgilerin girilmesi (kriterler, projeler)
import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import { v4 as uuidv4 } from 'uuid';
import { UserContext } from '../UserContext';
import './styles.css';

const socket = io('http://localhost:5000');

function CreateCompetitionPage() {
    const navigate = useNavigate();
    const { user } = useContext(UserContext);

    const [competitionName, setCompetitionName] = useState('');
    const [competitionDate, setCompetitionDate] = useState('');
    const [criteria, setCriteria] = useState([]);
    const [newCriterion, setNewCriterion] = useState('');
    const [projects, setProjects] = useState([]);
    const [newProjectName, setNewProjectName] = useState('');
    const [newProjectDescription, setNewProjectDescription] = useState('');

    // kriter ekleme
    const addCriterion = () => {
        if (newCriterion.trim()) {
            setCriteria([...criteria, newCriterion.trim()]);
            setNewCriterion('');
        }
    };

    // kriter editleme
    const handleCriterionChange = (index, value) => {
        const updatedCriteria = [...criteria];
        updatedCriteria[index] = value;
        setCriteria(updatedCriteria);
    };

    // kriter silme
    const deleteCriterion = (index) => {
        setCriteria(criteria.filter((_, i) => i !== index));
    };

    // proje ekleme
    const addProject = () => {
        if (newProjectName.trim() && newProjectDescription.trim()) {
            setProjects([
                ...projects,
                {
                    id: uuidv4(),
                    name: newProjectName.trim(),
                    description: newProjectDescription.trim(),
                },
            ]);
            setNewProjectName('');
            setNewProjectDescription('');
        } else {
            alert('Lütfen tüm alanları doldurun.');
        }
    };

    // proje duzenleme
    const handleProjectChange = (index, key, value) => {
        const updatedProjects = [...projects];
        updatedProjects[index] = {
            ...updatedProjects[index],
            [key]: value,
        };
        setProjects(updatedProjects);
    };

    // proje silme
    const deleteProject = (index) => {
        setProjects(projects.filter((_, i) => i !== index));
    };

    const handleCreateCompetition = () => {
        if (competitionName && competitionDate && criteria.length && projects.length) {
            const competitionId = uuidv4();
            socket.emit('createCompetition', {
                name: competitionName,
                date: competitionDate,
                criteria,
                projects,
                competitionId,
                createdBy: user.name,
            });
            navigate(`/competition/${competitionId}`);
        } else {
            alert('Lütfen tüm alanları, yarışma tarihi de dahil olmak üzere doldurun.');
        }
    };

    return (
        <div className="container">
            <h1>Yarışma Oluştur</h1>
            <div style={{ marginBottom: '15px' }}>
                <label>Yarışma Adı:</label>
                <input
                    type="text"
                    value={competitionName}
                    onChange={(e) => setCompetitionName(e.target.value)}
                />
            </div>
            <div style={{ marginBottom: '15px' }}>
                <label>Yarışma Tarihi:</label>
                <input
                    type="date"
                    value={competitionDate}
                    onChange={(e) => setCompetitionDate(e.target.value)}
                />
            </div>
            <div style={{ marginBottom: '15px' }}>
                <h3>Kriterler</h3>
                <input
                    type="text"
                    placeholder="Kriter Ekle"
                    value={newCriterion}
                    onChange={(e) => setNewCriterion(e.target.value)}
                />
                <button onClick={addCriterion} style={{ marginTop: '10px' }}>
                    Kriter Ekle
                </button>
                <ul style={{ marginTop: '15px' }}>
                    {criteria.map((criterion, index) => (
                        <li key={index}>
                            <input
                                type="text"
                                value={criterion}
                                onChange={(e) => handleCriterionChange(index, e.target.value)}
                                style={{ width: '80%' }}
                            />
                            <button onClick={() => deleteCriterion(index)} style={{ marginLeft: '10px' }}>
                                Sil
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
            <div style={{ marginBottom: '15px' }}>
                <h3>Projeler</h3>
                <input
                    type="text"
                    placeholder="Proje Adı"
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Proje Açıklaması"
                    value={newProjectDescription}
                    onChange={(e) => setNewProjectDescription(e.target.value)}
                />
                <button onClick={addProject} style={{ marginTop: '10px' }}>
                    Proje Ekle
                </button>
                <ul style={{ marginTop: '15px' }}>
                    {projects.map((project, index) => (
                        <li key={project.id}>
                            <input
                                type="text"
                                value={project.name}
                                onChange={(e) => handleProjectChange(index, 'name', e.target.value)}
                                style={{ width: '40%' }}
                            />
                            <input
                                type="text"
                                value={project.description}
                                onChange={(e) => handleProjectChange(index, 'description', e.target.value)}
                                style={{ width: '40%' }}
                            />
                            <button onClick={() => deleteProject(index)} style={{ marginLeft: '10px', backgroundColor: '#dc3545', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                                Sil
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
            <button onClick={handleCreateCompetition} style={{ width: '100%', padding: '10px', backgroundColor: '#28a745', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', marginTop: '15px' }}>
                Yarışma Oluştur
            </button>
        </div>
    );
}

export default CreateCompetitionPage;
